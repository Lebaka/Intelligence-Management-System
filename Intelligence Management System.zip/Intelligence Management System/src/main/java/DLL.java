public class DLL {
    private Person head;
    private int size = 0;

    public Person getHead(){
        return head;
    }

    public void push(String name, String surname, Integer age, String profession,
                     String gender, Double height, Double weight,
                     String eyecolor, String haircolor, Integer matchrank){
        Person person  = new Person();
        person.setName(name);
        person.setSurname(surname);
        person.setAge(age);
        person.setProfession(profession);
        person.setGender(gender);
        person.setHeight(height);
        person.setWeight(weight);
        person.setEyecolor(eyecolor);
        person.setHaircolor(haircolor);
        person.setMatchrank(matchrank);
        person.right=head;
        person.left=null;
        if(head!=null){
            head.left = person;
        }
        head=person;
    }

    public void append(String name, String surname, Integer age, String profession,
                       String gender, Double height, Double weight,
                       String eyecolor, String haircolor, Integer matchrank){
        Person person  = new Person();
        person.setName(name);
        person.setSurname(surname);
        person.setAge(age);
        person.setProfession(profession);
        person.setGender(gender);
        person.setHeight(height);
        person.setWeight(weight);
        person.setEyecolor(eyecolor);
        person.setHaircolor(haircolor);
        person.setMatchrank(matchrank);
        Person last = head;
        person.right = null;
        if(head==null){
            person.left = null;
            head = person;
            return;
        }
        while(last.right!=null){
            last = last.right;
        }
        last.right = person;
        person.left = last;
    }

    public void append(Person newPerson){
        Person last = head;
        newPerson.right = null;
        if(head==null){
            newPerson.left = null;
            head = newPerson;
            return;
        }
        while(last.right!=null){
            last = last.right;
        }
        last.right = newPerson;
        newPerson.left = last;
        setSize(getSize()+1);
    }

    public void printList(Person person){
        System.out.println("traversal in forward direction");
        while(person != null){
            System.out.println(person.getName());
            person = person.right;
        }
    }

    public void clearDLL(Person head){
        if(head!=null){
            clearDLL(head.right);
            head=null;
        }
        else{
            System.out.println("The DLL is already empty");
        }
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
