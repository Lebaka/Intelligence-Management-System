import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class BST {
    private Person root;
    public BST(){root =null;}

    public Person getRoot(){
        return root;
    }

    public void insert(Person newPerson){
        root = insertPerson(root, newPerson);
    }

    private Person insertPerson(Person root, Person newPerson){
        if(root == null){
            root = newPerson;
            return root;
        }
        if(newPerson.getName().compareTo(root.getName()) < 0){
            root.left = insertPerson(root.left, newPerson);
        }
        else if(newPerson.getName().compareTo(root.getName()) > 0 ||
                newPerson.getName().compareTo(root.getName())==0){
            root.right=insertPerson(root.right, newPerson);
        }
        return root;
    }

    public void JSON2BST(JSONArray jsonArray){
        if(jsonArray != null) {
            for (Object o : jsonArray) {
                Person person = new Person();
                new JSONObject();
                JSONObject personObj;
                personObj = (JSONObject) o;

                if (personObj.get("Age")!=null){
                    person.setAge(Integer.parseInt(personObj.get("Age").toString()));
                }
                if(personObj.get("Weight")!=null){
                    person.setWeight(Double.parseDouble(personObj.get("Weight").toString()));
                }
                if(personObj.get("Name")!=null){
                    person.setName((String) personObj.get("Name"));
                }
                if(personObj.get("Surname")!=null){
                    person.setSurname((String) personObj.get("Surname"));
                }
                if(personObj.get("Gender")!=null){
                    person.setGender((String) personObj.get("Gender"));
                }
                if(personObj.get("Height")!=null){
                    person.setHeight(Double.parseDouble(personObj.get("Height").toString()));
                }
                if(personObj.get("Eyecolor")!=null){
                    person.setEyecolor((String) personObj.get("Eyecolor"));
                }
                if(personObj.get("Haircolor")!=null){
                    person.setHaircolor((String) personObj.get("Haircolor"));
                }
                if(personObj.get("Profession")!=null){
                    person.setProfession((String) personObj.get("Profession"));
                }
                if(personObj.get("Surname")!=null){
                    person.setEducation((String) personObj.get("Education"));
                }
                this.insert(person);
            }
        }
        else
        {
            System.out.println("JSON Array has not been fetched. Check your connection please!");
        }
    }

    public void searchtoDLL(DLL dll, Person currentPerson, String name, String surname, Integer age, String gender,
                             Double weight, Double height, String eyecolor, String haircolor,
                             String profession, String education){

        Person newperson = new Person();
        if(currentPerson == null){
            System.out.println("Nothing found");
            return;
        }

        if(currentPerson.getName()!=null) {
                if (currentPerson.getName().toUpperCase().compareTo(name.toUpperCase()) == 0) {
                    currentPerson.incrementMatchrank();
                }
            }

            if(currentPerson.getSurname()!=null){
                if (currentPerson.getSurname().toUpperCase().compareTo(surname.toUpperCase()) == 0){
                    currentPerson.incrementMatchrank();
                }
            }

            if(currentPerson.getAge()!=null){
                if (currentPerson.getAge().equals(age)){
                    currentPerson.incrementMatchrank();
                }
            }

            if(currentPerson.getGender()!=null && gender!=null){
                if(currentPerson.getGender().compareTo(gender)==0){
                    currentPerson.incrementMatchrank();
                }
            }

            if(currentPerson.getWeight()!=null){
                if(currentPerson.getWeight().equals(weight)){
                    currentPerson.incrementMatchrank();
                }
            }

            if(currentPerson.getHeight()!=null) {
                if (currentPerson.getHeight().equals(height)) {
                    currentPerson.incrementMatchrank();
                }
            }
            if(currentPerson.getEyecolor()!=null){
                if (currentPerson.getEyecolor().toUpperCase().compareTo(eyecolor.toUpperCase())==0){
                    currentPerson.incrementMatchrank();
                }
            }

            if (currentPerson.getHaircolor()!=null){
                if(currentPerson.getHaircolor().toUpperCase().compareTo(haircolor.toUpperCase())==0){
                    currentPerson.incrementMatchrank();
                }
            }
            if (currentPerson.getProfession()!=null) {
                if (currentPerson.getProfession().toUpperCase().compareTo(profession.toUpperCase()) == 0) {
                    currentPerson.incrementMatchrank();
                }
            }
            if(currentPerson.getEducation() != null) {
                if (currentPerson.getEducation().toUpperCase().compareTo(education.toUpperCase()) == 0) {
                    currentPerson.incrementMatchrank();
                }
            }
            newperson.addProps(currentPerson.getName(), currentPerson.getSurname(),
                    currentPerson.getAge(), currentPerson.getProfession(), currentPerson.getEducation(),
                    currentPerson.getGender(), currentPerson.getHeight(), currentPerson.getWeight(),
                    currentPerson.getEyecolor(), currentPerson.getHaircolor(), currentPerson.getMatchrank());
            System.out.println("matchrank of " + newperson.getName()+" is : " + newperson.getMatchrank());



        if(currentPerson.left!=null)
        {
            searchtoDLL(dll, currentPerson.left, name, surname, age, gender,
                    weight, height, eyecolor, haircolor, profession, education);
        }

        if (currentPerson.right!=null){

            searchtoDLL(dll, currentPerson.right, name, surname, age, gender,
                    weight, height, eyecolor, haircolor, profession, education);
        }

        if(newperson.getName()!=null && newperson.getMatchrank() > 0) {
            dll.append(newperson);
        }
    }


    public void traverseInorder(Person root){
        if(root!=null) {
            traverseInorder(root.left);
            System.out.println(root.getName());
            traverseInorder(root.right);
        }
    }


    public void inorderTraversal() {inorderT(root); }


    private void inorderT(Person person) {
        if (person != null) {
            inorderT(person.left);
            System.out.print(person.getName() + " ");
            inorderT(person.right);
        }
    }
}
