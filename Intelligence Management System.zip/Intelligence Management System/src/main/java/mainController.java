import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.net.URL;
import java.util.ResourceBundle;

public class mainController implements Initializable {

    @FXML
    private JFXTextField txt_name;

    @FXML
    private JFXTextField txt_surname;

    @FXML
    private JFXTextField txt_age;

    @FXML
    private JFXTextField txt_height;

    @FXML
    private JFXTextField txt_weight;

    @FXML
    private JFXTextField txt_haircolor;

    @FXML
    private JFXTextField txt_eyecolor;

    @FXML
    private JFXTextField txt_profession;

    @FXML
    private JFXTextField txt_education;

    @FXML
    private JFXButton btn_exit;

    @FXML
    private TableView<Person> tbl_person;

    @FXML
    private TableColumn<Person, String> tblcol_name;

    @FXML
    private TableColumn<Person, String> tblcol_surname;

    @FXML
    private TableColumn<Person, Integer> tblcol_age;

    @FXML
    private TableColumn<Person, String> tblcol_gender;

    @FXML
    private TableColumn<Person, Double> tblcol_height;

    @FXML
    private TableColumn<Person, Double> tblcol_weight;

    @FXML
    private TableColumn<Person, String> tblcol_eyecolor;

    @FXML
    private TableColumn<Person, String> tblcol_haircolor;

    @FXML
    private TableColumn<Person, String> tblcol_profession;

    @FXML
    private TableColumn<Person, String> tblcol_education;

    @FXML
    private TableColumn<Person, Integer> tblcol_match;

    @FXML
    private JFXButton btn_search;

    @FXML
    private JFXComboBox<String> cmb_gender;

    @FXML
    private StackPane stackpane_main;
    private double xOffset, yOffset;



    @Override
    public void initialize(URL url, ResourceBundle rb) {

        tblcol_name.setCellValueFactory(new PropertyValueFactory<Person, String>("Name"));
        tblcol_surname.setCellValueFactory(new PropertyValueFactory<Person, String>("Surname"));
        tblcol_age.setCellValueFactory(new PropertyValueFactory<Person, Integer>("Age"));
        tblcol_gender.setCellValueFactory(new PropertyValueFactory<Person, String>("Gender"));
        tblcol_height.setCellValueFactory(new PropertyValueFactory<Person, Double>("Height"));
        tblcol_weight.setCellValueFactory(new PropertyValueFactory<Person, Double>("Weight"));
        tblcol_eyecolor.setCellValueFactory(new PropertyValueFactory<Person, String>("Eyecolor"));
        tblcol_haircolor.setCellValueFactory(new PropertyValueFactory<Person, String>("Haircolor"));
        tblcol_profession.setCellValueFactory(new PropertyValueFactory<Person, String>("Profession"));
        tblcol_education.setCellValueFactory(new PropertyValueFactory<Person, String>("Education"));
        tblcol_match.setCellValueFactory(new PropertyValueFactory<Person, Integer>("Matchrank"));

        btn_exit.setOnMouseClicked(event -> {
            closeButtonAction();
        });

        cmb_gender.getItems().clear();
        cmb_gender.getItems().addAll("Female","Male");
        JSONArray people = null;
        try {
            people = getJSONarr(getClass().getResource("people.json").getPath());

        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONArray finalPeople = people;
        btn_search.setOnAction(event -> {
            BST bst = new BST();
            DLL dll = new DLL();
            bst.JSON2BST(finalPeople);
            String name = txt_name.getText();
            String surname = txt_surname.getText();
            Integer age = null;
            Double height = null;
            Double weight = null;
            String gender = null;
            if(!txt_age.getText().equals("")){
                age = Integer.parseInt(txt_age.getText());
            }
            if(!txt_height.getText().equals("")){
                height = Double.parseDouble(txt_height.getText());
            }
            if(!txt_weight.getText().equals("")){
                weight = Double.parseDouble(txt_weight.getText());
            }

            String haircolor = txt_haircolor.getText();
            String eyecolor = txt_eyecolor.getText();
            String profession = txt_profession.getText();
            String education = txt_education.getText();

            if (cmb_gender.getSelectionModel().getSelectedItem()!=null){
                gender = cmb_gender.getSelectionModel().getSelectedItem();
            }
            bst.searchtoDLL(dll, bst.getRoot(), name, surname, age, gender, weight, height, eyecolor,
                    haircolor, profession, education);
            dll.printList(dll.getHead());

            tbl_person.getItems().clear();

            ObservableList<Person> personData = FXCollections.observableArrayList();
            Person head = dll.getHead();

            while(head!=null){
                Person person = new Person();
                person.setName(head.getName());
                person.setSurname(head.getSurname());
                person.setAge(head.getAge());
                person.setGender(head.getGender());
                person.setHeight(head.getHeight());
                person.setWeight(head.getWeight());
                person.setEyecolor(head.getEyecolor());
                person.setHaircolor(head.getHaircolor());
                person.setProfession(head.getProfession());
                person.setEducation(head.getEducation());
                person.setMatchrank(head.getMatchrank());
                personData.add(person);
                head = head.right;
            }



            tbl_person.setItems(personData);
            bst = null;
            dll = null;
        });

        stackpane_main.setOnMousePressed(mouseEvent -> {
            xOffset = mouseEvent.getSceneX();
            yOffset = mouseEvent.getSceneY();
        });

        stackpane_main.setOnMouseDragged(mouseEvent -> {
            Stage stage = (Stage)stackpane_main.getScene().getWindow();
            stage.setX(mouseEvent.getScreenX()-xOffset);
            stage.setY(mouseEvent.getScreenY()-yOffset);
        });

    }

    private JSONArray getJSONarr(String filename) throws Exception {
        JSONArray people = null;
        JSONParser jsonParser = new JSONParser();
        try (FileReader fr = new FileReader(filename)) {
            Object obj = jsonParser.parse(fr);
            people = (JSONArray)obj;
        }
        return people;
    }

    private void closeButtonAction(){

        Stage stage = (Stage) btn_exit.getScene().getWindow();
        stage.close();
    }
}