public class Person {
    private String Name;
    private String Surname;
    private Integer Age;
    private String Profession;
    private String Gender;
    private Double Height;
    private Double Weight;
    private String Eyecolor;
    private String Haircolor;
    public Person left;
    public Person right;
    private String Education;
    private int Matchrank = 0;

    public Person(){
        this.setMatchrank(0);
    }

    public void addProps(String name, String surname, Integer age, String profession, String education,
                         String gender, Double height, Double weight, String eyecolor,
                         String haircolor, int matchrank){
        this.setName(name);
        this.setSurname(surname);
        this.setAge(age);
        this.setProfession(profession);
        this.setEducation(education);
        this.setGender(gender);
        this.setHeight(height);
        this.setWeight(weight);
        this.setEyecolor(eyecolor);
        this.setHaircolor(haircolor);
        this.setMatchrank(matchrank);
    }

    public void incrementMatchrank(){
        this.setMatchrank(this.getMatchrank()+1);
    }

    public int getMatchrank() {
        return Matchrank;
    }

    public void setMatchrank(int matchrank) {
        Matchrank = matchrank;
    }

    public String getEducation() {
        return Education;
    }

    public void setEducation(String education) {
        Education = education;
    }



    public String getHaircolor() {
        return Haircolor;
    }

    public void setHaircolor(String haircolor) {
        Haircolor = haircolor;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String surname) {
        Surname = surname;
    }

    public Integer getAge() {
        return Age;
    }

    public void setAge(Integer age) {
        Age = age;
    }

    public String getProfession() {
        return Profession;
    }

    public void setProfession(String profession) {
        Profession = profession;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public Double getHeight() {
        return Height;
    }

    public void setHeight(Double height) {
        Height = height;
    }

    public Double getWeight() {
        return Weight;
    }

    public void setWeight(Double weight) {
        Weight = weight;
    }

    public String getEyecolor() {
        return Eyecolor;
    }

    public void setEyecolor(String eyecolor) {
        Eyecolor = eyecolor;
    }
}
